Q: How’s my pad?
“Your ABI improved 10% this week based on your stride. You walked 5000 steps this week, which is 20% above your goal. Keep up the good work! “
“Your ABI got 10% worse this week, based on your stride. You walked 3000 steps this week, which is 20% below your goal.“
Q: What is pad?
Peripheral artery disease (PAD) happens when plaque builds up in the wall of arteries in your legs, causing them to narrow, making walking painful.
Q: How can I improve my pad?
Simple walking regimens and leg exercises can ease symptoms. A doctor can recommend a good treatment plan. Other important factors are improving diet, stopping smoking, and managing diabetes.
Q: Can you help me find a doctor to treat my pad?
The closest doctor to you is  _______. I texted you a link with more information.