const SKILL_NAME = "PAD Piper"

const APP_VERSION = 0.1;

const APP_STATES = {
    NEW_USER: "",
    UNDEFINED: "undefined",
    MAIN: "_MAIN"
}

module.exports = {
    SKILL_NAME: SKILL_NAME,
    APP_VERSION: APP_VERSION,
    APP_STATES: APP_STATES
}